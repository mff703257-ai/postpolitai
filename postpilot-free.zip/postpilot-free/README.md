# PostPilot AI - free edition (no Firebase billing)

Choose a photo -> it is cropped for Instagram -> Gemini AI writes title, caption, hashtags -> it posts to Instagram.
Runs on Netlify's free plan. Photos only (Reels need paid hosting).

## You need (all free)
1. Gemini API key: aistudio.google.com > Get API key. (Free tier; Google may use free-tier prompts to improve its products.)
2. Instagram token + account ID: Meta dashboard > Instagram > "Generate token" next to your account. Copy the token and the number under your username.
3. A password you choose (anyone without it cannot use your site).

## Deploy (Command Prompt, inside this folder)
```
npm install
netlify login
netlify init
netlify env:set APP_PASSWORD yourpassword
netlify env:set GEMINI_API_KEY your_gemini_key
netlify env:set IG_TOKEN your_instagram_token
netlify env:set IG_USER_ID your_instagram_account_number
netlify deploy --prod
```
`netlify init`: choose "Create & configure a new project", press Enter for the build questions.
Open the link Netlify prints, enter your password, choose a photo.

## Notes
- Token lasts about 60 days. Then: `netlify env:set IG_TOKEN new_token` and `netlify deploy --prod`.
- Instagram allows about 100 API posts per 24 hours.
- Account must be Professional (Business/Creator) and added as an Instagram Tester in your Meta app.
- Optional settings: GEMINI_MODEL (default gemini-2.5-flash), GRAPH_VERSION (default v23.0).
