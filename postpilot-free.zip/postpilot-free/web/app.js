// PostPilot AI (free edition). All secrets live in Netlify settings; this page only holds your password.
const $ = (id) => document.getElementById(id), sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let file = null, up = null, host = null;
const toast = (t) => { const el = $("toast"); el.textContent = t; el.style.display = "block"; clearTimeout(toast.t); toast.t = setTimeout(() => (el.style.display = "none"), 5000); };
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
async function withBusy(btn, label, work) { const old = btn.textContent; btn.disabled = true; btn.textContent = label; try { return await work(); } catch (e) { toast(e.message || "Something went wrong."); } finally { btn.disabled = false; btn.textContent = old; } }

async function api(action, data = {}) {
  let pw = localStorage.getItem("pp_pw");
  if (!pw) { pw = prompt("Enter your PostPilot password (the APP_PASSWORD you set in Netlify):") || ""; localStorage.setItem("pp_pw", pw); }
  const r = await fetch("/api", { method: "POST", headers: { "content-type": "application/json", "x-app-password": pw }, body: JSON.stringify({ action, ...data }) });
  const j = await r.json().catch(() => ({}));
  if (r.status === 401) { localStorage.removeItem("pp_pw"); throw new Error("Wrong password. Try again."); }
  if (!r.ok) throw new Error(j.error || "Server error " + r.status);
  return j;
}
$("pw").onclick = () => { localStorage.removeItem("pp_pw"); toast("Password cleared. You will be asked next time."); };

// ----- History (kept in this browser) -----
const getLog = () => { try { return JSON.parse(localStorage.getItem("pp_log") || "[]"); } catch { return []; } };
function addLog(e) { localStorage.setItem("pp_log", JSON.stringify([{ ...e, at: Date.now() }, ...getLog()].slice(0, 40))); render(); }
function render() {
  const l = getLog(); $("posted").textContent = l.filter((x) => x.ok).length; $("failed").textContent = l.filter((x) => !x.ok).length;
  $("posts").className = l.length ? "" : "empty";
  $("posts").innerHTML = l.length ? l.map((x) => `<div class="post"><b>${esc(x.title || "Post")}</b><small>${new Date(x.at).toLocaleString()} · ${x.ok ? "published" : "failed"}</small>${x.err ? `<small class="err">${esc(x.err)}</small>` : ""}</div>`).join("") : "No posts yet.";
}
$("clear").onclick = () => { localStorage.removeItem("pp_log"); render(); };

// ----- Photo: any JPG/PNG/WebP is converted + auto-cropped to Instagram rules -----
async function toJpeg(f, img) {
  const w = img.naturalWidth, h = img.naturalHeight, r = w / h;
  let sx = 0, sy = 0, sw = w, sh = h;
  if (r > 1.91) { sw = Math.round(h * 1.9); sx = (w - sw) >> 1; } else if (r < 0.8) { sh = Math.round(w / 0.81); sy = (h - sh) >> 1; }
  const k = Math.min(1, 1440 / sw), c = document.createElement("canvas");
  c.width = Math.round(sw * k); c.height = Math.round(sh * k);
  c.getContext("2d").drawImage(img, sx, sy, sw, sh, 0, 0, c.width, c.height);
  return new Promise((ok, no) => c.toBlob((b) => (b ? ok(new File([b], "photo.jpg", { type: "image/jpeg" })) : no(new Error("convert"))), "image/jpeg", 0.88));
}
$("media").onchange = async (e) => {
  const f = e.target.files[0]; if (!f) return; up = null;
  const reject = (m) => { e.target.value = ""; file = null; $("preview").replaceChildren(); toast(m); };
  if (!/^image\/(jpeg|png|webp)$/.test(f.type)) return reject("Use a JPG, PNG or WebP photo.");
  const el = document.createElement("img");
  try { await new Promise((ok, no) => { el.onload = ok; el.onerror = no; el.src = URL.createObjectURL(f); }); file = await toJpeg(f, el); } catch { return reject("This photo could not be read."); }
  if (file.size > 4.5 * 1048576) return reject("Photo is too large after conversion.");
  el.style.cssText = "max-width:100%;max-height:220px;border-radius:12px"; $("preview").replaceChildren(el);
  if ($("autoOn").checked) $("auto").click();
};
const b64 = (f) => new Promise((ok, no) => { const r = new FileReader(); r.onload = () => ok(String(r.result).split(",")[1]); r.onerror = no; r.readAsDataURL(f); });
async function ensureUpload(btn) {
  if (!file) throw new Error("Choose a photo first.");
  if (up && up.file === file) return up;
  btn.textContent = "Uploading…"; return (up = { file, ...(await api("upload", { imageBase64: await b64(file) })) });
}

// ----- AI -----
async function generate(u) {
  const r = await api("generate", { k: u.k, brief: $("brief").value, language: $("lang").value, style: $("style").value });
  $("title").value = r.title; $("caption").value = r.caption; $("hashtags").value = r.hashtags.join(" ");
  $("cta").textContent = r.cta.length ? "Call-to-action ideas: " + r.cta.join(" | ") : "";
}
$("ai").onclick = () => withBusy($("ai"), "Working…", async () => { const u = await ensureUpload($("ai")); $("ai").textContent = "AI is writing…"; await generate(u); toast("Done. Edit anything, then press Post."); });

// ----- Publish: short steps so every server call stays quick -----
async function publish(u, btn) {
  const caption = [$("title").value.trim(), $("caption").value.trim(), $("hashtags").value.trim()].filter(Boolean).join("\n\n").slice(0, 2200);
  btn.textContent = "Sending to Instagram…";
  const c = await api("create", { imageUrl: u.url, caption, host }); host = c.host;
  for (let i = 0; ; i++) {
    const s = await api("status", { creationId: c.creationId, host });
    if (s.status_code === "FINISHED") break;
    if (s.status_code === "ERROR" || s.status_code === "EXPIRED") throw new Error("Instagram could not process the photo: " + (s.status || s.status_code));
    if (i >= 25) throw new Error("Instagram is taking too long. Check your profile, then try again.");
    await sleep(2000);
  }
  btn.textContent = "Publishing…"; await api("publish", { creationId: c.creationId, host });
  api("remove", { k: u.k }).catch(() => {});
}
async function run(btn, label, withAI) {
  const title = () => $("title").value;
  try {
    const u = await ensureUpload(btn);
    if (withAI) { btn.textContent = "AI is writing…"; await generate(u); }
    await publish(u, btn);
    addLog({ ok: true, title: title() }); toast("Posted to Instagram ✔");
    file = null; up = null; $("media").value = ""; $("preview").replaceChildren(); ["title", "caption", "hashtags", "brief"].forEach((k) => ($(k).value = ""));
  } catch (e) { addLog({ ok: false, title: title() || "Post", err: e.message }); throw e; }
}
$("auto").onclick = () => withBusy($("auto"), "Working…", () => run($("auto"), "", true));
$("post").onclick = () => withBusy($("post"), "Working…", () => { if (!$("caption").value.trim()) throw new Error("Write a caption first, or use Auto-post."); return run($("post"), "", false); });

render();
api("me").then((r) => { host = r.host; $("igStatus").textContent = "@" + r.username; }).catch((e) => { $("igStatus").textContent = "Not connected"; toast(e.message); });
