import assert from "node:assert";
const mem = new Map(); globalThis.__store = { set: async (k, v) => mem.set(k, v), get: async (k) => mem.get(k) ?? null, delete: async (k) => mem.delete(k) };
Object.assign(process.env, { APP_PASSWORD: "pw", GEMINI_API_KEY: "g", IG_TOKEN: "TOK", IG_USER_ID: "17841" });
const calls = [];
globalThis.fetch = async (url, o = {}) => {
  url = String(url); calls.push(url);
  const ok = (j) => ({ ok: true, status: 200, json: async () => j }), bad = (m) => ({ ok: false, status: 400, json: async () => ({ error: { message: m } }) });
  if (url.includes("generativelanguage")) { calls.gem = JSON.parse(o.body); return ok({ candidates: [{ content: { parts: [{ text: '```json\n{"title":"Golden Hour Glow","caption":"Sunsets hit different.","hashtags":["sunset","#golden hour"],"keywords":["sky"],"cta":["Follow"]}\n```' }] } }] }); }
  if (url.startsWith("https://graph.instagram.com")) return bad("Invalid OAuth access token");
  if (url.includes("/17841?")) return ok({ username: "myname" });
  if (url.includes("/17841/media_publish")) return ok({ id: "POST1" });
  if (url.includes("/17841/media")) { calls.create = new URLSearchParams(o.body); return ok({ id: "555" }); }
  if (url.includes("/555?")) return ok({ status_code: "FINISHED" });
  throw new Error("unexpected " + url);
};
const api = (await import("./netlify/functions/api.mjs")).default;
const img = (await import("./netlify/functions/img.mjs")).default;
const call = (b, pw = "pw") => api(new Request("https://my.netlify.app/api", { method: "POST", headers: { "x-app-password": pw }, body: JSON.stringify(b) }));
let r = await call({ action: "me" }, "nope"); assert.equal(r.status, 401); console.log("1 password required OK");
r = await call({ action: "me" }); let j = await r.json(); assert.deepEqual(j, { username: "myname", host: "graph.facebook.com" }); console.log("2 connect + host fallback OK");
const jpeg = Buffer.concat([Buffer.from([0xff, 0xd8, 0xff, 0xe0]), Buffer.alloc(2000, 7)]).toString("base64");
r = await call({ action: "upload", imageBase64: "AAAA" }); assert.equal(r.status, 500); console.log("3 rejects non-JPEG OK");
r = await call({ action: "upload", imageBase64: jpeg }); const up = await r.json(); assert(up.url.startsWith("https://my.netlify.app/img/") && up.url.endsWith(".jpg")); console.log("4 upload OK");
r = await img(new Request(up.url)); assert.equal(r.status, 200); assert.equal(r.headers.get("content-type"), "image/jpeg"); assert.equal((await r.arrayBuffer()).byteLength, 2004); console.log("5 public photo link OK");
assert.equal((await img(new Request("https://my.netlify.app/img/../../etc.jpg"))).status, 404); console.log("6 bad link blocked OK");
r = await call({ action: "generate", k: up.k, style: "short", language: "English" }); j = await r.json();
assert.equal(j.title, "Golden Hour Glow"); assert.deepEqual(j.hashtags, ["#sunset", "#goldenhour"]); assert(calls.gem.contents[0].parts[1].inline_data.data.length > 100); console.log("7 AI reads photo OK");
r = await call({ action: "create", imageUrl: up.url, caption: "Hi", host: j.host }); const c = await r.json(); assert.equal(c.creationId, "555"); assert.equal(c.host, "graph.facebook.com"); assert.equal(calls.create.get("image_url"), up.url); console.log("8 create container OK");
r = await call({ action: "create", imageUrl: "https://evil.com/img/" + up.k + ".jpg", caption: "x" }); assert.equal(r.status, 500); console.log("9 foreign image link blocked OK");
j = await (await call({ action: "status", creationId: "555", host: c.host })).json(); assert.equal(j.status_code, "FINISHED");
j = await (await call({ action: "publish", creationId: "555", host: c.host })).json(); assert.equal(j.id, "POST1"); console.log("10 status + publish OK");
await call({ action: "remove", k: up.k }); assert.equal((await img(new Request(up.url))).status, 404); console.log("11 cleanup OK");
