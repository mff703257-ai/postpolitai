// Public photo link so Instagram can download the picture before publishing.
async function images() { if (globalThis.__store) return globalThis.__store; const { getStore } = await import("@netlify/blobs"); return getStore("images"); }
export default async (req) => {
  const k = new URL(req.url).pathname.split("/").pop().replace(/\.jpg$/, "");
  if (!/^[a-f0-9]{32}$/.test(k)) return new Response("Not found", { status: 404 });
  const data = await (await images()).get(k, { type: "arrayBuffer" });
  if (!data) return new Response("Not found", { status: 404 });
  return new Response(data, { headers: { "content-type": "image/jpeg", "cache-control": "public, max-age=3600" } });
};
export const config = { path: "/img/*" };
