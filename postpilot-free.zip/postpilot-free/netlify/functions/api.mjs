// PostPilot (free) - one Netlify Function. Secrets are Netlify environment variables, never in the browser.
import { timingSafeEqual, randomBytes } from "node:crypto";
const E = process.env, VER = () => E.GRAPH_VERSION || "v23.0", HOSTS = ["graph.instagram.com", "graph.facebook.com"];
const json = (o, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { "content-type": "application/json" } });
const same = (a, b) => { const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && timingSafeEqual(x, y); };
async function images() { if (globalThis.__store) return globalThis.__store; const { getStore } = await import("@netlify/blobs"); return getStore("images"); }
const KEY = /^[a-f0-9]{32}$/;
const ig = (h, path, q) => `https://${h}/${VER()}/${path}${q ? "?" + new URLSearchParams(q) : ""}`;
async function meta(url, opts) {
  const r = await fetch(url, opts), j = await r.json().catch(() => ({}));
  if (!r.ok || j.error) throw new Error(j.error?.message || `Meta HTTP ${r.status}`);
  return j;
}
// Tries both Instagram hosts unless the browser already knows which one works.
async function onHost(host, fn) {
  let last = "";
  for (const h of host ? [host] : HOSTS) { try { return { host: h, ...(await fn(h)) }; } catch (e) { last = e.message; } }
  throw new Error("Instagram said: " + last);
}
const clean = (a) => (Array.isArray(a) ? a.map(String) : []);

const actions = {
  async me() { return onHost(null, async (h) => ({ username: (await meta(ig(h, E.IG_USER_ID, { fields: "username", access_token: E.IG_TOKEN }))).username || E.IG_USER_ID })); },

  async upload(b, req) {
    const buf = Buffer.from(String(b.imageBase64 || ""), "base64");
    if (buf.length < 1000 || buf.length > 5 * 1048576 || buf[0] !== 0xff || buf[1] !== 0xd8) throw new Error("Send a JPEG photo under 5 MB.");
    const k = randomBytes(16).toString("hex");
    await (await images()).set(k, buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.length));
    return { k, url: `${new URL(req.url).origin}/img/${k}.jpg` };
  },

  async generate(b) {
    if (!KEY.test(String(b.k))) throw new Error("Bad image id.");
    const data = await (await images()).get(b.k, { type: "arrayBuffer" });
    if (!data) throw new Error("Image not found. Upload again.");
    const style = ["short", "long", "promotional", "sales", "reel"].includes(b.style) ? b.style : "short";
    const lang = ["English", "Hindi", "Kannada"].includes(b.language) ? b.language : "English";
    const prompt = `You write Instagram posts. Look at the photo and write the post for it. Reply ONLY with JSON: {"title": short catchy headline max 8 words, "caption": string, "hashtags": [10-15 strings], "keywords": [5-8 strings], "cta": [3 call-to-action ideas]}. Caption style: ${style}. Language: ${lang}. Extra context from the owner: ${String(b.brief || "none").slice(0, 300)}`;
    const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${E.GEMINI_MODEL || "gemini-2.5-flash"}:generateContent`, {
      method: "POST", headers: { "content-type": "application/json", "x-goog-api-key": E.GEMINI_API_KEY || "" },
      body: JSON.stringify({ contents: [{ parts: [{ text: prompt }, { inline_data: { mime_type: "image/jpeg", data: Buffer.from(data).toString("base64") } }] }], generationConfig: { response_mime_type: "application/json" } }),
    });
    const j = await r.json().catch(() => ({}));
    if (r.status === 429) throw new Error("Free AI limit reached. Wait a minute and try again.");
    if (!r.ok) throw new Error("AI request failed: " + (j.error?.message || r.status));
    const txt = String(j.candidates?.[0]?.content?.parts?.[0]?.text || "").replace(/^```(?:json)?|```$/g, "").trim();
    let o; try { o = JSON.parse(txt); } catch { throw new Error("AI gave an unreadable answer. Try again."); }
    return { title: String(o.title || "").slice(0, 100), caption: String(o.caption || "").slice(0, 1700), hashtags: clean(o.hashtags).slice(0, 15).map((h) => "#" + h.replace(/^#/, "").replace(/\s+/g, "")), keywords: clean(o.keywords), cta: clean(o.cta) };
  },

  async create(b, req) {
    const m = String(b.imageUrl || "").match(/\/img\/([a-f0-9]{32})\.jpg$/);
    if (!m || new URL(b.imageUrl).origin !== new URL(req.url).origin) throw new Error("Bad image link.");
    const body = new URLSearchParams({ access_token: E.IG_TOKEN, image_url: b.imageUrl, caption: String(b.caption || "").slice(0, 2200) });
    const r = await onHost(b.host, async (h) => ({ creationId: (await meta(ig(h, `${E.IG_USER_ID}/media`), { method: "POST", body })).id }));
    return { creationId: r.creationId, host: r.host };
  },

  async status(b) {
    if (!/^\d+$/.test(String(b.creationId))) throw new Error("Bad id.");
    const j = await meta(ig(b.host, b.creationId, { fields: "status_code,status", access_token: E.IG_TOKEN }));
    return { status_code: j.status_code, status: j.status || "" };
  },

  async publish(b) {
    if (!/^\d+$/.test(String(b.creationId))) throw new Error("Bad id.");
    const j = await meta(ig(b.host, `${E.IG_USER_ID}/media_publish`), { method: "POST", body: new URLSearchParams({ creation_id: b.creationId, access_token: E.IG_TOKEN }) });
    if (!j.id) throw new Error("Instagram did not confirm the post.");
    return { id: j.id };
  },

  async remove(b) { if (KEY.test(String(b.k))) await (await images()).delete(b.k); return { ok: true }; },
};

export default async (req) => {
  if (req.method !== "POST") return json({ error: "POST only" }, 405);
  if (!E.APP_PASSWORD || !same(req.headers.get("x-app-password") || "", E.APP_PASSWORD)) return json({ error: "Wrong password." }, 401);
  let b; try { b = await req.json(); } catch { return json({ error: "Bad request." }, 400); }
  if (!Object.hasOwn(actions, b.action)) return json({ error: "Unknown action." }, 400);
  try { return json(await actions[b.action](b, req)); } catch (e) { return json({ error: e.message }, 500); }
};
export const config = { path: "/api" };
